Calibre-KyoboBook-Metadata-Source-Plugin
========================================

[Calibre](https://calibre-ebook.com/) Metadata Source Plugin for [KYOBO BOOK CENTRE](http://www.kyobobook.co.kr/)(Korean Book Metadata)  
캘리버 교보문고 책정보 가져오기 플러그인 

Korean(한글) - [README.ko.md](README.ko.md) 


Install
-------
1. [release](https://github.com/sseeookk/Calibre-KyoboBook-Metadata-Source-Plugin/releases) - Download the latest "KyoboBook.zip".
2. calibre - Prefrerence -Plugins - Load plugin from file 

Calibre Plugins Forum
---------------------
[Metadata Source Plugin] KyoboBook (Korean, kyobobook.co.kr)
http://www.mobileread.com/forums/showthread.php?t=236273

