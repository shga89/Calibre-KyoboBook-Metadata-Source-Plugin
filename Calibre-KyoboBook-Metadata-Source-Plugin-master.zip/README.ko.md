
[캘리버](https://calibre-ebook.com/)(Calibre, 도서 관리 프로그램) 플러그인 : [인터넷 교보문고](http://www.kyobobook.co.kr/)에서 책 정보, 책 표지 등을 가져옴.

설치 방법
---------
1. [release](https://github.com/sseeookk/Calibre-KyoboBook-Metadata-Source-Plugin/releases)에서 최신 버전의 KyoboBook.zip을 다운 받는다.
2. 캘리버에서 Preferences 창을 연다.
3. Advanced 그룹의 Plugins 항목을 선택한다. Plugins 창이 열린다.
4. Plugins 창에서 Load plugin from file 단추를 눌러 다운받은 KyoboBook.zip을 골라 플러그인을 설치하거나 업데이트 한다.
5. Plugins 창의 Metadata source plugins에서 KyoboBook를 찾아 선택한 다음 "Enable/disable plugin" 단추를 눌러 사용하도록 설정한다.
5. 이제 책의 "Edit Metadata" 창에서 "Download metadata" 단추를 눌러 책정보와 책표지를 받아올 수 있다.
